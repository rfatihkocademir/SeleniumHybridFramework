package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class ProductPage extends AbstractBase{

    //constructor
    public ProductPage(WebDriver driver) {

    }

    @Override
    public void openWebsite(String url) {
        driver.get(url);
    }

    @Override
    public void click(By element) {

    }

    @Override
    public void getText(By element) {

    }

    @Override
    public void enterInput(By element, String email) {

    }

    @Override
    public void isExist(By element) {

    }

    @Override
    public void titleCheck(String browserTitle) {

    }

    @Override
    public void TextAssertion(By element, String string) {

    }

    @Override
    public void checkList(By element) {

    }

    @Override
    public void hitEnter(By element) {

    }

    @Override
    public void InputClear(By element) {

    }

    @Override
    public void checkUrl(String url) {

    }
}
