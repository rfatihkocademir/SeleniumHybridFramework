Manuel test taskı için oluşturduğum excel içinde 2 adet sheet bulunmaktadır.

Kısıtlı süre içerisinde çıkarabiliğim önemli caseleri çıkarmaya çalıştım.
Süre arttıkça daha fazla case üretilebilir.

Aynı şekilde önem derecesi yüksek olan bugları listelemeye çalıştım.
Yüzde yüz test yoktur ilkesinden dolayı daha fazla bug bulunabileceğinin farkındayım. 

Umarım beklentiyi karşılayabilirim :)

Teşekkürler.